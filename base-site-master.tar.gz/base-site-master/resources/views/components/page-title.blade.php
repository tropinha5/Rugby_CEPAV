<h1 class="mt-4{{ !empty($class) ? ' '.$class : '' }}">{{ $title }}</h1>
