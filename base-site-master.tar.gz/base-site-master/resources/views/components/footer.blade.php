<div class="wsufooter">
    <div class="wsuwrap">
        <div class="privacy">
            <p><a href="https://wayne.edu/policies/">Privacy and University Policies</a></p>
        </div>
        <div class="copyright">
            <p><a href="https://wayne.edu/">Wayne State University</a> &copy; {{ date('Y') }}</p>
        </div>
    </div>
</div>
