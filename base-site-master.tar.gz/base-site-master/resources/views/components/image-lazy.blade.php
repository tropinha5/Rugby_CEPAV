<img class="lazy {{ empty($class) ?  'min-w-full' : $class }}"  src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="{{ $src }}" alt="{{ $alt }}">
