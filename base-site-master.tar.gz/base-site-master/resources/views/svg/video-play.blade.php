<svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 70" style="enable-background:new 0 0 100 70;" xml:space="preserve" aria-labelledby="{{ $label ?? $name }}">
    <title id="{{ $label ?? $name }}">{{ $name}}</title>
    <g>
        <path style="fill: #000;" d="M95.9,12.5c-1.2-5.1-5.3-8.8-10.3-9.3C73.8,1.9,61.9,1.9,50,1.9s-23.8,0-35.6,1.3c-5,0.6-9.1,4.3-10.3,9.3c-1.7,7.2-1.7,15-1.7,22.5s0,15.3,1.7,22.5c1.2,5.1,5.3,8.8,10.3,9.3c11.8,1.3,23.7,1.3,35.6,1.3s23.8,0,35.6-1.3c5-0.6,9.1-4.3,10.3-9.3c1.7-7.2,1.7-15,1.7-22.5C97.5,27.6,97.5,19.7,95.9,12.5z"/>
    </g>
    <polygon style="fill: #fff;" points="37.6,49.5 37.6,18.1 67.8,33.9 "/>
</svg>
