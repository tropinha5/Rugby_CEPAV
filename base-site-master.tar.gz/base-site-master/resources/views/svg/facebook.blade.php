<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 32" width="16" height="32" class="{{ $class ?? '' }}" aria-labelledby="{{ $label ?? $name }}">
    <title id="{{ $label ?? $name }}">{{ $name }}</title>
    <path d="M16 6.592h-4.544q-0.448 0-0.8 0.48t-0.352 1.184v3.264h5.696v4.736h-5.696v14.144h-5.44v-14.144h-4.864v-4.736h4.864v-2.752q0-3.008 1.888-5.088t4.704-2.080h4.544v4.992z"></path>
</svg>
